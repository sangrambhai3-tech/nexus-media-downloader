# Nexus Media Downloader

A small FastAPI website for downloading **direct public audio/video file URLs** that you own or are authorized to save.

## Run on your computer
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn app:app --host 127.0.0.1 --port 8000
   ```
4. Open http://127.0.0.1:8000

## Important
- YouTube and Instagram share-page URLs are not direct media-file URLs. This app intentionally does not extract streams, bypass DRM, logins, or platform restrictions.
- For your own YouTube uploads, use YouTube Studio / Google Takeout. For your own Instagram content, use Instagram's official download/export tools.
- Before deploying publicly, add authentication, rate limits, storage cleanup, stricter host allowlists, and HTTPS. The demo stores downloads in `downloads/`.
